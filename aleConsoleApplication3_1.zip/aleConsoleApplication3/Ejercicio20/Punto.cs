﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Punto
    {
        private int _x;
        private int _y;

        public int getX()
        {
            return this._x;
        }

        public int getY()
        {
            return this._y;
        }
    }
}
