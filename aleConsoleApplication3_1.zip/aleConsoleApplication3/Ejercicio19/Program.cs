﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio19
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo b1 = new Boligrafo(ConsoleColor.Blue, 100);
            Boligrafo b2 = new Boligrafo(ConsoleColor.Red, 50);
        }
    }
}
